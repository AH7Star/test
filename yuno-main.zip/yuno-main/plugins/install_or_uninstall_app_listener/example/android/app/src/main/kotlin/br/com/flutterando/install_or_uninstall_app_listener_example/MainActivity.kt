package br.com.flutterando.install_or_uninstall_app_listener_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
