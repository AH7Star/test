const igdbClientId = String.fromEnvironment('IGDB_CLIENT_ID');
const igdbToken = String.fromEnvironment('IGDB_TOKEN');
const rawqToken = String.fromEnvironment('RAWQ_TOKEN');
