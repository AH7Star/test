import 'package:asp/asp.dart';

import '../models/app_model.dart';

final appsState = Atom<List<AppModel>>([]);
