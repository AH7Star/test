package com.example.icthub_new_repo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
